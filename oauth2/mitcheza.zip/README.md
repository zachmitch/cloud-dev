Author:  Zach Mitchell*, mitcheza@oregonstate.edu
CS493, FALL 2018 - HW6 OAUTH2.0
11/8/2018

* Used a Bootstrap template for html landing page
https://startbootstrap.com/template-overviews/freelancer/

File to be graded for HW6:  app.js
