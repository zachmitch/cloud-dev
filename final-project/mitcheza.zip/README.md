Author - Zach Mitchell, mitcheza@oregonstate.edu
CS493 - Final Project, Art Collecting Cloud api w/authentication & authorization
12/3/2018

A video demo of this project can be at https://www.youtube.com/watch?v=Gi9NsUkpjS8

Forgive me if sections of the video are sped up to get it under the 10 minute limit.
